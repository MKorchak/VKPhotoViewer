//
//  Albums.swift
//  VKPhotoViewer
//
//  Created by Misha Korchak on 06.02.17.
//  Copyright © 2017 Misha Korchak. All rights reserved.
//

import Foundation
import UIKit

class Albums {
    
    var thumbURL: String = ""
    var title: String = ""
    var id: Int = 0
    
}
